drop table if exists Covid19s;
drop table if exists Cities;
drop table if exists __EFMigrationsHistory; 